<?php 

    $db = mysqli_connect("localhost", "root", "", "elections") or die("Connectivity Failed");

?>