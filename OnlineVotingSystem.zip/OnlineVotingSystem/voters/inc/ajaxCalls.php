<?php 
    require_once("../admin/inc/config.php");
    
    if (isset($_POST['election_id']) && isset($_POST['candidate_id']) && isset($_POST['voters_id'])) {
        $election_id = $_POST['election_id'];
        $candidate_id = $_POST['candidate_id'];
        $voters_id = $_POST['voters_id'];
    
        // Check if the user has already casted vote for this election
        $checkIfVoteCasted = mysqli_query($db, "SELECT * FROM votings WHERE voters_id = '$voters_id' AND election_id = '$election_id'");
        $isVoteCasted = mysqli_num_rows($checkIfVoteCasted);
    
        if ($isVoteCasted > 0) {
            // User has already casted vote for this election, update the vote
            mysqli_query($db, "UPDATE votings SET candidate_id = '$candidate_id' WHERE voters_id = '$voters_id' AND election_id = '$election_id'");
        } else {
            // User has not casted vote for this election, insert the vote
            $vote_date = date("Y-m-d");
            $vote_time = date("h:i:s a");
    
            mysqli_query($db, "INSERT INTO votings (election_id, voters_id, candidate_id, vote_date, vote_time) VALUES ('$election_id', '$voters_id', '$candidate_id', '$vote_date', '$vote_time')");
        }
    
        echo "Success";
    } else {
        echo "Error: Insufficient data.";
    }
    ?>