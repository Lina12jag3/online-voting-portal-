<?php 
require_once("inc/header.php");
require_once("inc/navigation.php");
?>

<div class="row my-3">
    <div class="col-12">
        <h3> Voters Panel </h3>

        <?php 
        $fetchingActiveElections = mysqli_query($db, "SELECT * FROM addelections WHERE status = 'Active'") or die(mysqli_error($db));
        $totalActiveElections = mysqli_num_rows($fetchingActiveElections);

        if ($totalActiveElections > 0) {
            while ($data = mysqli_fetch_assoc($fetchingActiveElections)) {
                $election_id = $data['id'];
                $election_topic = $data['election_topic'];    
        ?>
                <div class="card mb-4">
                    <div class="card-header bg-green text-white">
                        <h5 class="card-title">ELECTION TOPIC: <?php echo strtoupper($election_topic); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php 
                            $fetchingCandidates = mysqli_query($db, "SELECT * FROM candidate_details WHERE election_id = '". $election_id ."'") or die(mysqli_error($db));

                            while ($candidateData = mysqli_fetch_assoc($fetchingCandidates)) {
                                $candidate_id = $candidateData['id'];
                                $candidate_photo = $candidateData['candidate_photo'];

                                // Fetching Candidate Votes 
                                $fetchingVotes = mysqli_query($db, "SELECT * FROM votings WHERE candidate_id = '". $candidate_id . "'") or die(mysqli_error($db));
                                $totalVotes = mysqli_num_rows($fetchingVotes);

                                // Check if user has already voted for this election
                                $checkIfVoteCasted = mysqli_query($db, "SELECT * FROM votings WHERE voters_id = '". $_SESSION['user_id'] ."' AND election_id = '". $election_id ."'") or die(mysqli_error($db));    
                                $isVoteCasted = mysqli_num_rows($checkIfVoteCasted);

                                // Initialize $voteCastedToCandidate variable
                                $voteCastedToCandidate = null;

                                if ($isVoteCasted > 0) {
                                    $voteCastedData = mysqli_fetch_assoc($checkIfVoteCasted);
                                    $voteCastedToCandidate = $voteCastedData['candidate_id'];
                                }

                                // Calculate the total number of candidates contesting in this election
                                $totalCandidates = mysqli_num_rows($fetchingCandidates);

                                // Check if there is only one candidate and handle the voting options accordingly
                                $hasSingleCandidate = $totalCandidates == 1;
                            ?>
                                <div class="col-md-4">
                                    <div class="card mb-3">
                                        <img src="<?php echo $candidate_photo; ?>" class="card-img-top" alt="Candidate Photo">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo $candidateData['candidate_name']; ?></h5>
                                            <p class="card-text"><?php echo $candidateData['candidate_manifesto']; ?></p>

                                            <?php if ($isVoteCasted > 0) { ?>
                                                <?php if ($voteCastedToCandidate == $candidate_id) { ?>
                                                    <img src="../assets/images/vote.png" width="100px;">
                                                <?php } ?>
                                            <?php } else { ?>
                                                <form action="cast_vote.php" method="post">
                                                    <input type="hidden" name="election_id" value="<?php echo $election_id; ?>">
                                                    <input type="hidden" name="candidate_id[]" value="<?php echo $candidate_id; ?>">
                                                    <input type="hidden" name="voters_id" value="<?php echo $_SESSION['user_id']; ?>">
                                                    
                                                    <?php if ($hasSingleCandidate) { ?>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio" name="vote_option[<?php echo $candidate_id; ?>]" id="vote_option_yes_<?php echo $candidate_id; ?>" value="Yes">
                                                            <label class="form-check-label" for="vote_option_yes_<?php echo $candidate_id; ?>">Yes</label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio" name="vote_option[<?php echo $candidate_id; ?>]" id="vote_option_no_<?php echo $candidate_id; ?>" value="No">
                                                            <label class="form-check-label" for="vote_option_no_<?php echo $candidate_id; ?>">No</label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio" name="vote_option[<?php echo $candidate_id; ?>]" id="vote_option_nota_<?php echo $candidate_id; ?>" value="NOTA">
                                                            <label class="form-check-label" for="vote_option_nota_<?php echo $candidate_id; ?>">NOTA (None of the Above)</label>
                                                        </div>
                                                    <?php } else { ?>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio" name="vote_option[<?php echo $candidate_id; ?>]" id="vote_option_yes_<?php echo $candidate_id; ?>" value="Yes">
                                                            <label class="form-check-label" for="vote_option_yes_<?php echo $candidate_id; ?>">Yes</label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio" name="vote_option[<?php echo $candidate_id; ?>]" id="vote_option_no_<?php echo $candidate_id; ?>" value="No">
                                                            <label class="form-check-label" for="vote_option_no_<?php echo $candidate_id; ?>">No</label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio" name="vote_option[<?php echo $candidate_id; ?>]" id="vote_option_neutral_<?php echo $candidate_id; ?>" value="Neutral">
                                                            <label class="form-check-label" for="vote_option_neutral_<?php echo $candidate_id; ?>">Neutral</label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio" name="vote_option[<?php echo $candidate_id; ?>]" id="vote_option_nota_<?php echo $candidate_id; ?>" value="NOTA">
                                                            <label class="form-check-label" for="vote_option_nota_<?php echo $candidate_id; ?>">NOTA (None of the Above)</label>
                                                        </div>
                                                    <?php } ?>
                                                    
                                                    <button type="submit" class="btn btn-md btn-success mt-2">Vote</button>
                                                </form>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
        <?php
            }
        } else {
            echo "No any active election.";
        }
        ?>
    </div>
</div>

<!-- Rest of the code remains unchanged. -->


<script>
    const CastVote = (election_id, candidate_id, voters_id) => {
        const formData = {
            election_id: election_id,
            candidate_id: candidate_id,
            voters_id: voters_id
        };

        $.ajax({
            type: "POST",
            url: "inc/ajaxCalls.php",
            data: formData,
            success: function (response) {
                if (response === "Success") {
                    location.assign("index.php?voteCasted=1");
                } else {
                    location.assign("index.php?voteNotCasted=1");
                }
            },
            error: function (xhr, status, error) {
                console.log("Error casting vote: " + error);
                // Optionally handle the error here
            }
        });
    };
</script>

<?php
require_once("inc/footer.php");
?>
