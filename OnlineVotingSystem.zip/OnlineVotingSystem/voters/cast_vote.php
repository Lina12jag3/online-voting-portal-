<?php
require_once("../admin/inc/config.php");

if (isset($_POST['election_id']) && isset($_POST['candidate_id']) && isset($_POST['voters_id']) && isset($_POST['vote_option'])) {
    $election_id = $_POST['election_id'];
    $candidate_id = $_POST['candidate_id'];
    $voters_id = $_POST['voters_id'];
    $vote_option = $_POST['vote_option'];

    // Check if the voter has already cast a vote for this election
    $checkIfVoteCasted = mysqli_query($db, "SELECT * FROM votings WHERE voters_id = '$voters_id' AND election_id = '$election_id'") or die(mysqli_error($db));
    $isVoteCasted = mysqli_num_rows($checkIfVoteCasted);

    if ($isVoteCasted > 0) {
        // If the voter has already cast a vote, update their vote
        $updateVote = mysqli_query($db, "UPDATE votings SET candidate_id = '". mysqli_real_escape_string($db, serialize($candidate_id)) ."', vote_option = '". mysqli_real_escape_string($db, serialize($vote_option)) ."' WHERE voters_id = '$voters_id' AND election_id = '$election_id'") or die(mysqli_error($db));
        echo "Success";
    } else {
        // If the voter has not cast a vote, insert their vote into the database
        $vote_date = date("Y-m-d");
        $vote_time = date("h:i:s a");

        mysqli_query($db, "INSERT INTO votings (election_id, voters_id, candidate_id, vote_option, vote_date, vote_time) VALUES ('$election_id', '$voters_id', '". mysqli_real_escape_string($db, serialize($candidate_id)) ."', '". mysqli_real_escape_string($db, serialize($vote_option)) ."', '$vote_date', '$vote_time')") or die(mysqli_error($db));

        echo "vote casted";
    }
} else {
    echo "Error: Invalid request.";
}
?>
